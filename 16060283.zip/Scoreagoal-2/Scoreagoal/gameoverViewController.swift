//
//  gameoverViewController.swift
//  Scoreagoal
//
//  Created by ia17aar on 12/01/2020.
//  Copyright © 2020 ia17aar. All rights reserved.
//

import UIKit

class gameoverViewController: UIViewController {

    @IBOutlet weak var scorepoint: UILabel!
    
    var scoregot = ""
    
    @IBAction func restartG(_ sender: Any) {
        let game2 = UIStoryboard(name: "Main", bundle: nil)
        let gameplay2 = game2.instantiateViewController(identifier: "menu")
        self.present(gameplay2, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        scorepoint.text = scoregot

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
