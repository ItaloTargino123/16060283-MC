//
//  restartViewController.swift
//  Scoreagoal
//
//  Created by ia17aar on 11/01/2020.
//  Copyright © 2020 ia17aar. All rights reserved.
//

import UIKit

class restartViewController: UIViewController {
    
    @IBOutlet weak var scorepoint: UILabel!
    
    var scoregot = ""
    
    //@IBAction func nextlevel(_ sender: Any) {
       // let game = UIStoryboard(name: "Main", bundle: nil)
      //  let games = game.instantiateViewController(identifier: "nextlevel")
       // self.present(games, animated: true, completion: nil)
   // }
    
    @IBAction func nextlevel(_ sender: Any) {
        let gamen = UIStoryboard(name: "Main", bundle: nil)
        let gameplayn = gamen.instantiateViewController(identifier: "nextlevel")
        self.present(gameplayn, animated: true, completion: nil)
    }
    
    
  // @IBAction func restartG(_ sender: Any) {
      //  let game = UIStoryboard(name: "Main", bundle: nil)
           //    let gameplay = //game.instantiateViewController(identifier: //"gameScreen")
           //    self.present(gameplay, animated: true, completion: nil)
  //  }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        scorepoint.text = scoregot
        
    }
    

}
