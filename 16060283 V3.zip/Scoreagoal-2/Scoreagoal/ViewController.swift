//
//  ViewController.swift
//

import UIKit
import AVFoundation

protocol subviewDelegate {
    func generateBall()
    func updateBallAngle(currentLocation: CGPoint)
}


class ViewController: UIViewController, subviewDelegate {
    var audioPlayer: AVAudioPlayer?
    var score = 0
    var countdown = 20
    var timer = Timer()
    var dynamicAnimator:                UIDynamicAnimator!
    var dynamicItemBehavior:            UIDynamicItemBehavior!
    var collisionBehavior:              UICollisionBehavior!
    var postCollisionBehaviour:         UICollisionBehavior!
    var ballImageArray: [UIImageView]   = []
    var postViewArray: [UIImageView]    = []
    
    let W = UIScreen.main.bounds.width
    let H = UIScreen.main.bounds.height
    
    var vectorX: CGFloat? = 0
    var vectorY: CGFloat? = 0

    let postImageArray = [UIImage(named: "goal2.png")!,
                          UIImage(named: "goal3.png")!,
                          UIImage(named: "goal2.png")!,
                          UIImage(named: "goal5.png")!,
                          UIImage(named: "goal3.png")!,
                          
                          
    ]
    
    
    func updateBallAngle(currentLocation: CGPoint){
        vectorX = currentLocation.x
        vectorY = currentLocation.y
    }
    
    
    func generateBall() {
        
        let ballImage = UIImageView(image: nil)
        
        ballImage.image = UIImage(named: "soccer")
        
        ballImage.frame = CGRect(x: W*0.08, y: H*0.47, width: W*0.10, height: H*0.17)
        
        self.view.addSubview(ballImage)
        
        let angleX = vectorX! - self.Aim.bounds.midX
        let angleY = vectorY! - H*0.5
        
        ballImageArray.append(ballImage)
        
        dynamicItemBehavior.addItem(ballImage)
        
        dynamicItemBehavior.addLinearVelocity(CGPoint(x: angleX*5, y: angleY*5), for: ballImage)
        
        collisionBehavior.addItem(ballImage)
        
        let disappear = DispatchTime.now() + 2
         
        
        DispatchQueue.main.asyncAfter(deadline: disappear) {
            ballImage.removeFromSuperview()
            
        }
        
    }
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
 
        startUp()
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ViewController.counter), userInfo: nil, repeats: true)
        self.Aim.center.x = self.W * 0.10
        self.Aim.center.y = self.H * 0.50
        
        Aim.myDelegate = self
        
        dynamicAnimator = UIDynamicAnimator(referenceView: self.view)
        dynamicItemBehavior = UIDynamicItemBehavior(items: ballImageArray)
        dynamicAnimator.addBehavior(dynamicItemBehavior)
        dynamicAnimator.addBehavior(postCollisionBehaviour)
        
        collisionBehavior = UICollisionBehavior(items: [])
        
        
        collisionBehavior = UICollisionBehavior(items: ballImageArray)
        //collisionBehavior.translatesReferenceBoundsIntoBoundary = true
        
        collisionBehavior.addBoundary(withIdentifier: "LEFTBOUNDARY" as NSCopying, from: CGPoint(x: self.W*0.0, y: self.H*0.0), to: CGPoint(x: self.W*0.0, y: self.H*1.0))
        
        collisionBehavior.addBoundary(withIdentifier: "TOPBOUNDARY" as NSCopying, from: CGPoint(x: self.W*0.0, y: self.H*0.0), to: CGPoint(x: self.W*1.0, y: self.H*0.0))
       
        collisionBehavior.addBoundary(withIdentifier: "BOTTOMBOUNDARY" as NSCopying, from: CGPoint(x: self.W*0.0, y: self.H*1.0), to: CGPoint(x: self.W*1.0, y: self.H*1.0))
        
        dynamicAnimator.addBehavior(collisionBehavior)
        
       
        }
         
    override func didReceiveMemoryWarning() {
                   super.didReceiveMemoryWarning()
    }

    
    func createpostImage(){
        let number = 5
               let postSize = Int(self.H)/number-2
                   

                       for index in 0...1000{
                           
                           let when = DispatchTime.now() + (Double(index)/2)
                             
                            DispatchQueue.main.asyncAfter(deadline: when) {
                               
                               while true {
                                   
                                   let randomHeight = Int(self.H)/number * Int.random(in: 0...number)
                                   
                                   let postView = UIImageView(image: nil)
                                   
                                   postView.image = self.postImageArray.randomElement()
                                   
                                   postView.frame = CGRect(x: self.W-CGFloat(postSize), y:  CGFloat(randomHeight), width: CGFloat(postSize),
                                   height: CGFloat(postSize))
                                   
                                   self.view.addSubview(postView)
                                   self.view.bringSubviewToFront(postView)
                                   
                                   for anypostView in self.postViewArray {
                                       if
                                           postView.frame.intersects(anypostView.frame) {
                                           
                                           postView.removeFromSuperview()
                                           
                                           continue
                                       }
               
                                   
                               }
                                   
                                   self.postViewArray.append(postView)
                                   break;
                       }
                       
                       
                       
                   }
                           
            }
    }

        
    func startUp(){
            
            self.createpostImage()
            
            dynamicAnimator = UIDynamicAnimator(referenceView: self.view)
            
            
            Aim.frame = CGRect(x:W*0.02, y: H*0.4, width: W*0.2, height: H*0.2)
            Aim.myDelegate = self
            
            postCollisionBehaviour = UICollisionBehavior(items: postViewArray)
            
            self.postCollisionBehaviour.action = {
                for ballView in self.ballImageArray{
                    for postView in self.postViewArray{
                        let index = self.postViewArray.firstIndex(of: postView)
                        if ballView.frame.intersects(postView.frame)
                        
                        {
                            let pathToSound = Bundle.main.path(forResource: "applause2", ofType: "wav")!
                            let url = URL(fileURLWithPath: pathToSound)
                            do{
                                self.audioPlayer = try AVAudioPlayer(contentsOf: url)
                                self.audioPlayer?.play()
                                
                                
                            }
                            catch {
                            
                            }
                            postView.removeFromSuperview()
                            self.postViewArray.remove(at: index!)
                            self.score += 1
                          //  self.points.text = NSString(format:"Score: %i", self.score)
                          //  as String
                            self.updateScore()
                        }
                    }
                }
                
            }
            
            dynamicAnimator.addBehavior(postCollisionBehaviour)
            
            
    }
    func updateScore(){
        points.text = "Score " + "\(score)"
    }
    @objc func counter(){
        countdown -= 1
        timelimit.text = String(countdown)
        if (countdown == 0){
            timer.invalidate()
            timeUp()
        }
    }
    
    func timeUp(){
        performSegue(withIdentifier: "passScore", sender: self)
        let game = UIStoryboard (name: "Main", bundle: nil)
        let restart = game.instantiateViewController(identifier: "restartScreen")
        self.present(restart, animated: true, completion: nil)
        
    }
        
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        let scorePass = segue.destination as! restartViewController
        scorePass.scoregot = self.points.text!
        
    }
    
    
    
    @IBOutlet weak var Aim: DragImageView!
    
    
    @IBOutlet weak var points: UILabel!
    
    @IBOutlet weak var timelimit: UILabel!
    
    
}
